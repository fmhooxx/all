<template>
  <div class="counter-warp">
   主页
  </div>
</template>

<script>
  export default {
    data () {
      return {

      }
    },

    onLoad () {
    },
    // onShow(){
    //
    // },
    onUnload () {
    },
    methods: {
    }
  }
</script>

<style lang="stylus" scoped>

</style>
