<template>
  <div class="message">
    <div class="message-box">
      <div>
        <img src="/static/images/star.png" alt="">
      </div>
      <div style="margin-left: 20px">
        <div class="name-box"><span class="name">张钦北</span><span class="date">3分钟</span></div>
        <div class="instro">建议先服用药物控制，调理，看效果在做之后的治…</div>
      </div>
    </div>
    <div class="message-box">
      <div>
        <img src="/static/images/star.png" alt="">
      </div>
      <div style="margin-left: 20px">
        <div class="name-box"><span class="name">张钦北</span><span class="date">3分钟</span></div>
        <div class="instro">建议先服用药物控制，调理，看效果在做之后的治…</div>
      </div>
    </div>
  </div>
</template>

<script>
  export default {
    data () {
      return {

      }
    },

    onLoad () {
    },
    // onShow(){
    //
    // },
    onUnload () {
    },
    methods: {
      jump () {
        wx.navigateTo({
          url: '../../im/login/main'
        })
      }
    }
  }
</script>

<style lang="stylus" scoped>
  .message{
    padding 0 3%
    .message-box{
      padding 30rpx 0
      border-bottom 1rpx solid #ECECEC
      padding 25rpx 0
      display flex
      align-items center
      .name-box{
        display flex
        justify-content space-between
        color #525252
        font-size 30rpx
        .date{
          color #9B9B9B
          font-size 22rpx
        }
      }
      .instro{
        font-size 24rpx
        color #B6B6B6
        margin-top 10rpx
      }
      img{
        height 76rpx
        width 76rpx
      }
    }
  }
</style>
