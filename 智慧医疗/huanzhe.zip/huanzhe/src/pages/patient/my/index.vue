<template>
  <div class="mine-box">
   <div class="mine-hd">
     <div><img src="/static/images/star.png" alt=""><span>登录/注册</span></div>
     <div class="hd-list-box">
       <div class="hd-list">
         <span>150</span>
         <span>收藏</span>
       </div>
       <div class="hd-list">
         <span>23</span>
         <span>关注医生</span>
       </div>
       <div class="hd-list">
         <span>3210</span>
         <span>积分</span>
       </div>
       <div class="hd-list">
       <span>3</span>
       <span>优惠券</span>
     </div>
     </div>
   </div>
  </div>
</template>

<script>
  export default {
    data () {
      return {

      }
    },

    onLoad () {
    },
    // onShow(){
    //
    // },
    onUnload () {
    },
    methods: {
    }
  }
</script>

<style lang="stylus" scoped>
  .mine-box{
    .mine-hd{
      height 484rpx
      width 100%
      background-color #52C0B8
      .hd-list-box{
        display flex
        justify-content space-evenly
        .hd-list{
          display flex
          flex-direction column
          align-items center
          span{
            display inline-block
            padding 8rpx 0
          }
        }
      }
      > div{
        display flex
        align-items center
        padding 0 30rpx
        color #fff
        font-size 34rpx
        img{
          height 92rpx
          width 92rpx
          margin-right 38rpx
        }
      }
    }
  }
</style>
