<template>
  <div>好大夫返回热风管</div>
 </template>

<script>
  export default {
    data () {
      return {

      }
    }
  }
</script>

<style lang='stylus'>

</style>
