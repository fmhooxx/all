<template>
  <div>
    首页
  </div>
</template>

<script>
export default {
  data () {
    return {

    }
  },

  onLoad () {
  },
  // onShow(){
  //
  // },
  methods: {
  }
}
</script>

<style lang="stylus" scoped></style>
