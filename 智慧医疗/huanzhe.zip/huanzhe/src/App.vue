<script>
export default {
  created () {
  }
}
</script>

<style lang="stylus">
@import "stylus/base.styl"
.button-disabled
  color $white !important
  background-color $primary !important
  opacity 0.4
</style>
